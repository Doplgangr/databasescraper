var getID = function (){
	return document.location.href.substr(document.location.href.lastIndexOf('/') + 1);
}

var count = function(data)
{
	console.log("data is"+data);
	console.log("parse is"+data.match(/\/\*O_o\*\/\nX\((.*)\);/)[1]);
    	var tableData = JSON.parse(data.match(/\/\*O_o\*\/\nX\((.*)\);/)[1]);
	return tableData.table.rows.length;
};

var upload = function (data) {
	if (count(data) > 0)
		return;
	var question = $("div.richtext").text();
	console.log("question is: "+question);
	var answers = $("li.option").map(function() {
                 return $(this).text().replace(/^[#*]+/g, '');
              }).get();
	console.log(answers);
	var correct = $("li.option").map(function() {
		var matchedstring = $(this).text();
		if (matchedstring.match(/^[*]/g))
                 return matchedstring.replace(/^[.]/g, '*#').replace(/^[#*]+/g, '');
              }).get()[0];
	var questionexists = question!==undefined && question.length != 0;
	var answerexists = answers!==undefined && answers.length != 0;
	var correctexists = correct!==undefined && correct.length != 0;
	if (questionexists && answerexists && correctexists)
	var request = $.ajax({
            url: "https://script.google.com/macros/s/AKfycbzhF7yOHAHG-RiF1jgzZ4DvwgdmHkHjo29As4uciMCbWhAgfV0/exec",
            type: "post",
	    crossDomain: true,
            data: {
			QUESTION_CODE:getID(),
			QUESTION:question,
			CORRECT:correct,
			ANSWERS:JSON.stringify(answers)
		}
        });
}

var request = $.ajax({
            url: "https://docs.google.com/spreadsheets/d/1lIZeueadG24egWy1imSU2iBk3ASj0-X83rUU1zJ3RlU/gviz/tq?tq=select%20B%20where%20A%3D"+getID()+"&tqx=responseHandler:X;",
            type: "get",
	    crossDomain: true,
		success: upload
		
        });