
$('a.jq-colorbox').map(function() {
	var secretThing = $('<iframe></iframe>', { css: { 		'display': 'none' }});
	$('body').append(secretThing);
	secretThing.attr("src", $(this).attr('href'));
}
)